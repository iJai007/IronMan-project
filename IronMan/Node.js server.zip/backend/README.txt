Hello To whoever is reading this,

The code in this folder is the Node.js backend Server I'm currently creating as part of my final year project. It is an ongoing project with more features to come